#ifndef FD_H
#define FD_H

void parse_fd(char** cmd);

#endif