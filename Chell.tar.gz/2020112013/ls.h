#ifndef LS_H
#define LS_H

void parse_ls(char** cmd);

#endif