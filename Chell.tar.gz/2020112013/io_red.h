#ifndef IORED_H
#define IORED_H

void parse_io (char** cmds);
#endif