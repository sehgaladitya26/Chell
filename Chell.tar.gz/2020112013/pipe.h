#ifndef PIPE_H
#define PIPE_H

void parse_pipe (char* cmds);
#endif