#ifndef HISTORY_H
#define HISTORY_H

void read_history(char* last);
void history();

#endif