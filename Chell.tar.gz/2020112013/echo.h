#ifndef ECHO_H
#define ECHO_H

void print_echo(char** args);
#endif