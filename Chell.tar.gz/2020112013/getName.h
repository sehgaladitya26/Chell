#ifndef GETNAME_H
#define GETNAME_H

char* getusrName();

#endif